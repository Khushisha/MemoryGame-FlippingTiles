import nav.Navigation;

public class App {
    public static void main(String[] args) {
        Navigation.getNav();
    }
}

